#include "flat_hash_map.hpp"
#include "hash_set.h"
#include "sparsehash/dense_hash_map"
#include "robin-hood-hashing-master/src/include/robin_hood.h"
#include "robin-map-master/include/tsl/robin_map.h"
#include <random>
#include <iostream>
#include <unordered_map>

#ifdef _WIN32
#  include <Windows.h>
#else
#  include <time.h>
#endif

#ifdef _WIN32
class Timer
{
public:
    Timer(const char* msg, const char* msg2) :_msg(!msg2 ? msg : msg2), _start(GetTickCount()) {}
    ~Timer()
    {
        DWORD end = GetTickCount();
        printf("%14s: %u\n", _msg, (unsigned)(end - _start));
    }
private:
    const char* _msg;
    DWORD _start;
};
#else
class Timer
{
public:
    Timer(const char* msg) :_msg(msg) { clock_gettime(CLOCK_MONOTONIC_RAW, &_start); }
    ~Timer()
    {
        struct timespec end;
        clock_gettime(CLOCK_MONOTONIC_RAW, &end);

        //milliseconds
        double msec = double((end.tv_sec - _start.tv_sec) * 1000ULL) + double(end.tv_nsec - _start.tv_nsec)*0.000001;
        
        printf("%12s: %u\n", _msg, (unsigned)msec);
    }
private:
    const char* _msg;
    struct timespec _start;
};
#endif //_WIN32

const uint64_t MAX_ELEMENTS = 5000000;
uint64_t* ELEMENTS;

template<class T>
static void insert_operator(T& m, const char* msg = nullptr)
{
    Timer t("insert[]", msg);

    const uint64_t* end = ELEMENTS + MAX_ELEMENTS;
    for (uint64_t n = 20; n--;)
        for (const uint64_t* p = ELEMENTS; p != end; ++p)
            m[*p] = *p;
}

template<class T>
static void insert(T& m, const char* msg = nullptr)
{
    Timer t("insert", msg);

    const uint64_t* end = ELEMENTS + MAX_ELEMENTS;
    for (uint64_t n = 20; n--;)
        for (const uint64_t* p = ELEMENTS; p != end; ++p)
            m.insert(T::value_type(*p, *p));
}

template<class T>
static void emplace(T& m, const char* msg = nullptr)
{
    Timer t("emplace", msg);

    const uint64_t* end = ELEMENTS + MAX_ELEMENTS;
    for (uint64_t n = 20; n--;)
        for (const uint64_t* p = ELEMENTS; p != end; ++p)
            m.emplace(*p, *p);
}

template<class T>
static void erase(T& m, const char* msg = nullptr)
{
    Timer t("erase", msg);

    for (const uint64_t* p = ELEMENTS, *end = ELEMENTS + MAX_ELEMENTS; p != end; ++p)
        m.erase(*p);
}

template<class T>
static void find_erase(T& m, const char* msg = nullptr)
{
    Timer t("find_erase", msg);

    for (const uint64_t* p = ELEMENTS, *end = ELEMENTS + MAX_ELEMENTS; p != end; ++p) {
        auto it = m.find(*p);
        if (it != m.end())
            m.erase(it);
    }
}

template<class T>
static uint64_t find(const T& m, const char* msg = nullptr)
{
    uint64_t ret = 0;

    Timer t("find", msg);

    for (const uint64_t* p = ELEMENTS, *end = ELEMENTS + MAX_ELEMENTS; p != end; ++p) {
        auto it = m.find(*p);
        if (it != m.end())
            ret += it->second;
    }

    return ret;
}

template<class T>
static uint64_t count(const T& m, const char* msg = nullptr)
{
    uint64_t ret = 0;

    Timer t("count", msg);

    for (const uint64_t* p = ELEMENTS, *end = ELEMENTS + MAX_ELEMENTS; p != end; ++p) {
        ret += m.count(*p);
    }

    return ret;
}

template<class T>
static uint64_t copy_ctor(const T& m, const char* msg = nullptr)
{
    uint64_t ret = 0;

    Timer t("copy_ctor", msg);

    for (uint64_t n = 20; n--;) {
        T tmp(m);
        ret += tmp.size();
    }

    return ret;
}

template<class T>
static uint64_t copy_operator(const T& m, const char* msg = nullptr)
{
    uint64_t ret = 0;

    Timer t("copy_operator", msg);

    T tmp;
    for (uint64_t n = 20; n--;) {
        tmp = m;
        ret += tmp.size();
    }

    return ret;
}

template<class T>
static uint64_t TEST(const T& m, const char* msg = nullptr)
{
    uint64_t ret = 0;

    Timer t("TEST", msg);

    const size_t SIZE = 320 * 1024 * 1024;
    void* b = malloc(SIZE);
    for (uint64_t n = 20; n--;) {
        void* a = malloc(SIZE);
        memmove(a, b, SIZE);
        ret += *(uint64_t*)((char*)a + SIZE/2);
        free(a);
    }
    free(b);

    return ret;
}


template<class T>
static uint64_t test(T& m, const char* name)
{
    uint64_t ret = 0;
    puts(name);

    //TEST(m);
    //return 0;

/*
    m.clear();
    insert_operator(m);
    m.clear();
    emplace(m);

    m.clear();
    insert_operator(m);
    m.clear();
    emplace(m);
*/

    m.clear();
    insert_operator(m);
//    system("pause");
    erase(m);

    m.clear();
    insert(m, "insert(clear)");
    find_erase(m);
    insert(m, "insert(erase)"); // a lot of DELETED elements

    m.clear();
    emplace(m, "emplace(clear)");

    insert(m, "insert(neg)");
    ret = find(m);
    ret += count(m);

    copy_ctor(m);
    copy_operator(m);

    return ret;
}


static uint64_t xorshift(uint64_t n, uint64_t i) {
    return n ^ (n >> i);
}
static uint64_t rnd(uint64_t n) {
    uint64_t p = 0x5555555555555555; // pattern of alternating 0 and 1
    uint64_t c = 17316035218449499591ull;// random uneven integer constant; 
    return c * xorshift(p * xorshift(n, 32), 32);
}

int main()
{
    ELEMENTS = new uint64_t[MAX_ELEMENTS];
    
    //fill input data
    { 
/*
        std::random_device rd;
        std::mt19937_64 gen(rd());

        std::uniform_int_distribution<uint64_t> dis;
*/

        uint64_t offset = 1;

        for (uint64_t i = 0; i != MAX_ELEMENTS; ++i) {
            offset = rnd(i + offset);
            ELEMENTS[i] = offset;
            //ELEMENTS[i] = dis(gen);
        }
    }

    ska::flat_hash_map<uint64_t, uint64_t> m0;
    hrd::hash_map<uint64_t, uint64_t> m1;
    google::dense_hash_map<uint64_t, uint64_t> m2;
    m2.set_empty_key(0);
    m2.set_deleted_key(-1);
    std::unordered_map<uint64_t, uint64_t> m3;
    robin_hood::unordered_map<uint64_t, uint64_t> m4;
    tsl::robin_map<uint64_t, uint64_t> m5;

    m4[10] = 10;

    uint64_t ret = 0;
    ret -= test(m0, "ska::flat_hash_map");
    ret -= test(m1, "\nhrd::hash_map");
    ret -= test(m2, "\ngoogle::dense_hash_map");
    ret -= test(m3, "\nstd::unordered_map");
    ret -= test(m4, "\nrobin_hood::unordered_map");
    ret -= test(m5, "\ntsl::robin_map");

    delete[] ELEMENTS;

    return (int)ret;
}
