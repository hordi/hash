# about bench
  each cpp file can be complied and benched.

