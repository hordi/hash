#include "flat_hash_map.hpp"
#include "hash_set.h"
#include "sparsehash/dense_hash_map"
#include <random>
#include <iostream>
#include <unordered_map>

#ifdef _WIN32
#  include <Windows.h>
#else
#  include <time.h>
#endif

#ifdef _WIN32
class Timer
{
public:
    Timer(const char* msg) :_msg(msg), _start(GetTickCount()) {}
    ~Timer()
    {
        DWORD end = GetTickCount();
        printf("%12s: %u\n", _msg, (unsigned)(end - _start));
    }
private:
    const char* _msg;
    DWORD _start;
};
#else
class Timer
{
public:
    Timer(const char* msg) :_msg(msg), _start(GetTickCount()) { clock_gettime(CLOCK_MONOTONIC_RAW, &_start); }
    ~Timer()
    {
        struct timespec end;
        clock_gettime(CLOCK_MONOTONIC_RAW, &end);

        //milliseconds
        double msec = double((end.tv_sec - _start.tv_sec) * 1000ULL) + double(end.tv_nsec - _start.tv_nsec)*0.000001;
        
        printf("%12s: %f\n", _msg, msec);
    }
private:
    const char* _msg;
    struct timespec _start;
};
#endif //_WIN32

const uint64_t MAX_ELEMENTS = 5000000;
uint64_t* ELEMENTS;

template<class T>
static void insert(T& m)
{
    Timer t("insert");

    const uint64_t* end = ELEMENTS + MAX_ELEMENTS;
    for (uint64_t n = 20; n--;)
        for (const uint64_t* p = ELEMENTS; p != end; ++p)
            m[*p] = *p;
}

template<class T>
static void erase(T& m)
{
    Timer t("erase");

    for (const uint64_t* p = ELEMENTS, *end = ELEMENTS + MAX_ELEMENTS; p != end; ++p)
        m.erase(*p);
}

template<class T>
static void find_erase(T& m)
{
    Timer t("find_erase");

    for (const uint64_t* p = ELEMENTS, *end = ELEMENTS + MAX_ELEMENTS; p != end; ++p) {
        auto it = m.find(*p);
        if (it != m.end())
            m.erase(it);
    }
}

template<class T>
static uint64_t find(const T& m)
{
    uint64_t ret = 0;

    Timer t("find");

    for (const uint64_t* p = ELEMENTS, *end = ELEMENTS + MAX_ELEMENTS; p != end; ++p) {
        auto it = m.find(*p);
        if (it != m.end())
            ret += it->second;
    }

    return ret;
}

template<class T>
static uint64_t find_back(const T& m)
{
    uint64_t ret = 0;

    Timer t("find_back");

    for (const uint64_t* p = ELEMENTS + MAX_ELEMENTS; p-- != ELEMENTS;) {
        auto it = m.find(*p);
        if (it != m.end())
            ret += it->second;
    }

    return ret;
}

template<class T>
static uint64_t test(T& m, const char* name)
{
    puts(name);

    insert(m);
    erase(m);

    insert(m);
    find_erase(m);

    insert(m);
    uint64_t ret = find(m);
    ret += find_back(m);

    return ret;
}

/*
static uint64_t xorshift(uint64_t n, uint64_t i) {
    return n ^ (n >> i);
}
static uint64_t rnd(uint64_t n) {
    uint64_t p = 0x5555555555555555; // pattern of alternating 0 and 1
    uint64_t c = 17316035218449499591ull;// random uneven integer constant; 
    return c * xorshift(p * xorshift(n, 32), 32);
}
*/

int main()
{
    ELEMENTS = new uint64_t[MAX_ELEMENTS];
    
    //fill input data
    { 
        std::random_device rd;
        std::mt19937_64 gen(rd());

        std::uniform_int_distribution<uint64_t> dis;

        uint64_t offset = 1;

        for (uint64_t i = 0; i != MAX_ELEMENTS; ++i) {
            //uint64_t v = rnd(i + offset);
            //offset = v;
            //std::cout << v << '\n';
            ELEMENTS[i] = dis(gen);
        }
    }

    ska::flat_hash_map<uint64_t, uint64_t> m0;
    hordi::hash_map<uint64_t, uint64_t> m1;
    google::dense_hash_map<uint64_t, uint64_t> m2;
    m2.set_empty_key(0);
    m2.set_deleted_key(-1);
    std::unordered_map<uint64_t, uint64_t> m3;

    uint64_t ret = test(m0, "ska::flat_hash_map");
    ret -= test(m1, "\nhordi::hash_map");
    ret -= test(m2, "\ngoogle::dense_hash_map");
    ret -= test(m3, "\nstd::unordered_map");

    delete[] ELEMENTS;

    return (int)ret;
}
