#include "flat_hash_map.hpp"
#include "hash_set.h"
#include "sparsehash/dense_hash_map"
#include <random>
#include <iostream>
#include <unordered_map>
#include <Windows.h>

class Timer
{
public:
    Timer(const char* msg) :_msg(msg), _start(GetTickCount()) {}
    ~Timer()
    {
        DWORD end = GetTickCount();
        printf("%12s: %u\n", _msg, (unsigned)(end - _start));
    }
private:
    const char* _msg;
    DWORD _start;
};

const uint64_t MAX_ELEMENTS = 5000000;
uint64_t* ELEMENTS;

template<class T>
static void insert(T& m)
{
    Timer t("insert");

    for (uint64_t n = 20; n--;)
        for (uint64_t i = 0; i != MAX_ELEMENTS; ++i) {
            uint64_t v = ELEMENTS[i];
            m[v] = v;
        }
}

template<class T>
static void erase(T& m)
{
    Timer t("erase");

    for (uint64_t i = 0; i != MAX_ELEMENTS; ++i) {
        uint64_t v = ELEMENTS[i];
        m.erase(v);
    }
}

template<class T>
static void find_erase(T& m)
{
    Timer t("find_erase");

    for (uint64_t i = 0; i != MAX_ELEMENTS; ++i) {
        uint64_t v = ELEMENTS[i];

        auto it = m.find(v);
        if (it != m.end())
            m.erase(it);
    }
}

template<class T>
static uint64_t find(const T& m)
{
    uint64_t ret = 0;

    Timer t("find");

    for(uint64_t n = 10; n--;)
        for (uint64_t i = 0; i != MAX_ELEMENTS; ++i) {
            uint64_t v = ELEMENTS[i];

            auto it = m.find(v);
            if (it != m.end())
                ret += it->second;
        }

    return ret;
}

template<class T>
static uint64_t find_back(const T& m)
{
    uint64_t ret = 0;

    Timer t("find_back");

    for (uint64_t n = 20; n--;)
        for (uint64_t i = MAX_ELEMENTS; i--;) {
            uint64_t v = ELEMENTS[i];
            auto it = m.find(v);
            if (it != m.end())
                ret += it->second;
        }

    return ret;
}

template<class T>
static uint64_t test(T& m, const char* name)
{
    puts(name);

    insert(m);
    erase(m);

    insert(m);
    find_erase(m);

    insert(m);
    uint64_t ret = find(m);
    ret += find_back(m);

    return ret;
}

int main()
{
    ELEMENTS = new uint64_t[MAX_ELEMENTS];
    
    //fill input data
    { 
        std::random_device rd;
        std::mt19937_64 gen(rd());

        std::uniform_int_distribution<uint64_t> dis;

        for (uint64_t i = 0; i != MAX_ELEMENTS; ++i)
            ELEMENTS[i] = dis(gen);
    }


    ska::flat_hash_map<uint64_t, uint64_t> m0;
    hordi::hash_map<uint64_t, uint64_t> m1;
    google::dense_hash_map<uint64_t, uint64_t> m2;
    m2.set_empty_key(0);
    m2.set_deleted_key(-1);
    std::unordered_map<uint64_t, uint64_t> m3;

    uint64_t ret = test(m0, "ska::flat_hash_map");
    ret -= test(m1, "\nhordi::hash_map");
    ret -= test(m2, "\ngoogle::dense_hash_map");
    ret -= test(m3, "\nstd::unordered_map");

    delete[] ELEMENTS;

    return (int)ret;
}
