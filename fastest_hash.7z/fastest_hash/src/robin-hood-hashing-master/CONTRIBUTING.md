* Coding style should be consistent with the code around you.
* Use automatic formatting with clang-format.
* One feature per pull request
