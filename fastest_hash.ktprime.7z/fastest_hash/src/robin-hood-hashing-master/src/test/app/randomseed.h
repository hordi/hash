#ifndef APP_RANDOMSEED_H
#define APP_RANDOMSEED_H

#include <cstdint>

uint64_t randomseed();

#endif
